<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "helpdesk";

// Create connection
$connection = new mysqli($host, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Set character set to utf8
if (!$connection->set_charset("utf8")) {
    die("Error loading character set utf8: " . $connection->error);
}

?>
<?php

class Database
{
    private static $connection;

    public static function connect()
    {
        $host = "localhost";
        $username = "root";
        $password = "";
        $database = "helpdesk";

        self::$connection = new mysqli($host, $username, $password, $database);

        if (self::$connection->connect_error) {
            die("Connection failed: " . self::$connection->connect_error);
        }
    }

    public static function search($query)
    {
        if (!isset(self::$connection)) {
            self::connect();
        }

        $result = self::$connection->query($query);

        if (!$result) {
            die("Query failed: " . self::$connection->error);
        }

        return $result;
    }
}

?>

