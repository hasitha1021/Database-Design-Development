function signIn() {

    var email = document.getElementById("username");
    var password = document.getElementById("password");

    var form = new FormData();
    form.append("u", email.value);
    form.append("p", password.value);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var text = r.responseText;
            console.log(text);

            if (text == "success") {
                email.value = "";
                password.value = "";

                window.location = "home.php";
            }
        }
    }

    r.open("POST", "login_process.php", true);
    r.send(form);

}

function signUp() {

    var name = document.getElementById("name");
    var username = document.getElementById("username");
    var email = document.getElementById("email");
    var mobile = document.getElementById("mobile");
    var password = document.getElementById("password");
    // var terms = document.getElementById("terms");

    var form = new FormData();
    form.append("n", name.value);
    form.append("u", username.value);
    form.append("e", email.checked);
    form.append("m", mobile.value);
    form.append("p", password.value);
    // form.append("t", terms.checked);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var text = r.responseText;
            console.log(text);

            if (text == "success") {

                name.value = "";
                username.value = "";
                email.value = "";
                mobile.value = "";
                password.value = "";

            }

        }
    }

    r.open("POST", "new_user_process.php", true);
    r.send(form);
}

function sign_Out() {

    var r = new XMLHttpRequest();

    r.onreadystatechange = function() {
        if (this.readyState == 4) {
            var t = r.responseText;
            if (t == "success") {
                window.location = "home.php";
            }
        }
    }

    r.open("GET", "signOutProcess.php", true);
    r.send();

}


function signUpUser() {
    var name = document.getElementById("name");
    var username = document.getElementById("username");
    var email = document.getElementById("email");
    var mobile = document.getElementById("mobile");
    var password = document.getElementById("password");
    // var terms = document.getElementById("terms");

    var form = new FormData();
    form.append("n", name.value);
    form.append("u", username.value);
    form.append("e", email.value);
    form.append("m", mobile.value);
    form.append("p", password.value);
    // form.append("t", terms.checked);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var text = r.responseText;
            console.log(text);
            

            if (text == "success") {

                name.value = "";
                username.value = "";
                email.value = "";
                mobile.value = "";
                password.value = "";

            }

        }
    }

    r.open("POST", "user_process.php", true);
    r.send(form);
}

function pricing() {

    var name = document.getElementById("name");
    var email = document.getElementById("email");
    var mobile = document.getElementById("mobile");
    var pricing = document.getElementById("pricing");
    var events = document.getElementById("events");

    var form = new FormData();
    form.append("n", name.value);
    form.append("e", email.value);
    form.append("m", mobile.value);
    form.append("p", pricing.value);
    form.append("ev", events.value);
    // form.append("t", terms.checked);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var text = r.responseText;
            console.log(text);

            if (text == "success") {

                name.value = "";
                email.value = "";
                mobile.value = "";

            }

        }
    }

    r.open("POST", "pricing_process.php", true);
    r.send(form);
}

function deleteUser(id) {
    var uid = id;
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState == 4) {
            var text = request.responseText;
            if (text == "success") {
                window.location = "manageUsers.php";
            }
        }
    }

    request.open("GET", "removeUserProccess.php?id=" + uid, true);
    request.send();

}

function deleteAdmin(id) {
    var uid = id;
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState == 4) {
            var text = request.responseText;
            if (text == "success") {
                window.location = "manageAdmins.php";
            }
        }
    }

    request.open("GET", "removeAdminProccess.php?id=" + uid, true);
    request.send();

}

function updateUser(id){
    console.log("awa");
    var id = id;
    var name = document.getElementById("name");
    var username = document.getElementById("username");
    var email = document.getElementById("email");
    var mobile = document.getElementById("mobile");
    var password = document.getElementById("password");
    // var terms = document.getElementById("terms");

    var form = new FormData();
    form.append("n", name.value);
    form.append("u", username.value);
    form.append("e", email.value);
    form.append("m", mobile.value);
    form.append("p", password.value);
    // form.append("t", terms.checked);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var text = r.responseText;
            console.log(text);
            

            if (text == "success") {

                name.value = "";
                username.value = "";
                email.value = "";
                mobile.value = "";
                password.value = "";

            }

        }
    }

    r.open("POST", "updateUserProcess.php", true);
    r.send(form);
}

function updateAdmin(id){
    console.log("awa");
    var id = id;
    var name = document.getElementById("name");
    var username = document.getElementById("username");
    var email = document.getElementById("email");
    var mobile = document.getElementById("mobile");
    var password = document.getElementById("password");
    // var terms = document.getElementById("terms");

    var form = new FormData();
    form.append("n", name.value);
    form.append("u", username.value);
    form.append("e", email.value);
    form.append("m", mobile.value);
    form.append("p", password.value);
    // form.append("t", terms.checked);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var text = r.responseText;
            console.log(text);
            

            if (text == "success") {

                name.value = "";
                username.value = "";
                email.value = "";
                mobile.value = "";
                password.value = "";

            }

        }
    }

    r.open("POST", "updateAdminProcess.php", true);
    r.send(form);
}

