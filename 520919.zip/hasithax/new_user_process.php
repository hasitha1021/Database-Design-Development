<?php
session_start();
require "connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $mobile = $_POST["mobile"];
    $password = $_POST["psw"]; 

    if (empty($name) || strlen($name) > 50) {
        echo "Invalid Name";
    } elseif (empty($username) || strlen($username) > 50) {
        echo "Invalid Username";
    } elseif (empty($email) || strlen($email) >= 100) {
        echo "Invalid Email Address";
    } elseif (empty($password) || strlen($password) < 5 || strlen($password) > 20) {
        echo "Invalid Password";
    } elseif (empty($mobile) || strlen($mobile) != 10 || !preg_match("/07[0,1,2,4,5,6,7,8][0-9]/", $mobile)) {
        echo "Invalid Mobile Number";
    } /*else {
        // Check if user already exists
        $result = Database::search("SELECT * FROM `user` WHERE `email`='$email' OR `mobile`='$mobile'");
        $numRows = $result->num_rows;

        if ($numRows > 0) {
            echo "User with the same Email Address or Mobile Number already exists";
        }else {*/
            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert user data into the database
            $query = "INSERT INTO `user` (`name`, `username`, `email`, `mobile`, `password`) 
                      VALUES ('$name', '$username', '$email', '$mobile', '$hashedPassword')";

            if ($connection) {
                $result = mysqli_query($connection, $query);

                if ($result) {
                    echo "success";
                    header("Location: home.php");
                } else {
                    echo "Error: " . mysqli_error($connection);
                }

                // Close database connection
                mysqli_close($connection);
            } else {
                echo "Error: Unable to establish a database connection.";
            }
        }
    //}
//}
?>
