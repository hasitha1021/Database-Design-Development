<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('connection.php'); // Add a semicolon here
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $mobile = $_POST["mobile"];
    $package = $_POST["package"];
    $helpType = $_POST["types"];
    $operatorName = $_POST["operator_name"];
    $computerSerialNumber = $_POST["computer_serial_number"];
    $operatingSystem = $_POST["operating_system"];
    $softwareUsed = $_POST["software_used"];
    $problemDescription = $_POST["problem_description"];
    $employeeDepartment = $_POST["employee_department"];
    $equipmentType = $_POST["equipment_type"];

    // Insert data into the single table
    $query = "INSERT INTO `web_help_desk_table`(`name`, `email`, `mobile`, `package`,
             `types`, `operating_system`, `computer_serial_number`, `operating_system`, 
              `softwer_used`, `problem_description`, `employee_department`, `equipment_type`)
               VALUES ('$name', '$email', '$mobile', '$package', '$helpType', '$operatorName', 
               '$computerSerialNumber', '$operatingSystem', '$softwareUsed', 
               '$problemDescription', '$employeeDepartment', '$equipmentType')";

    // Execute the query
    if ($connection->query($query) === TRUE) {
        echo "Form submitted successfully. We will contact you within 24 hours.";
    } else {
        echo "Error: " . $query . "<br>" . $connection->error;
    }
}
?>

<!-- Your HTML form remains unchanged -->


<!-- HTML Form -->
<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Events</title>
    <link rel="stylesheet" href="home.css" />
    <link rel="stylesheet" href="mediaqueries.css" />

    <style>
        /* Style the container */
        .container {
            width: 60%;
            margin: 0 auto;
            padding: 20px;
            background-color: #f2f2f2;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        /* Style the form headings and labels */
        h1,
        p,
        label {
            font-family: Arial, sans-serif;
        }

        /* Style the text inputs and select box */
        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
        }

        /* Style the radio buttons and checkboxes */
        input[type="radio"],
        input[type="checkbox"] {
            margin-right: 5px;
        }

        /* Style the submit button */
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }

        /* Set a style for the submit button */
        .registerbtn {
            background-color: #3C21F7;
            color: white;
            padding: 16px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
            opacity: 0.9;
        }

        .registerbtn:hover {
            opacity: 1;
        }
    </style>
</head>
<body>

    <?php
    require "header.php";
    ?>

    <form action="" method="post" onsubmit="return displayAlert()">
        <div class="container">
            <h1>Select Your Package and Help types</h1>
            <p style="margin-top: 2%;">Please fill in this form.</p>
            <hr style="margin-bottom:3%;">

            <label for="name"><b>Name</b></label>
            <input type="text" placeholder="Enter Name" name="name" id="name" required>

            <label for="email"><b>Email</b></label>
            <input type="text" placeholder="Enter Email" name="email" id="email" required>

            <label for="mobile"><b>Mobile</b></label>
            <input type="text" placeholder="Enter Mobile" name="mobile" id="mobile" required>

            <br>
            <label for="package"><b>Select Package</b></label>
            <select id="package" name="package">
                <option value="basic">Basic Package</option>
                <option value="standard">Standard Package</option>
                <option value="premium">Premium Package</option>
            </select>

            <br>
            <label for="types"><b>Select Help Type</b></label>
            <select id="types" name="types">
                <option value="Web help desk">Web help desk</option>
                <option value="On-premise help desk">On-premise help desk</option>
                <option value="Enterprise help desk">Enterprise help desk</option>
                <option value="Open-source help desk">Open-source help desk</option>
                <option value="Cloud-based help desk">Cloud-based help desk</option>
            </select>

            <label for="operator_name">Operator Name:</label>
            <input type="text" id="operator_name" name="operator_name" required><br>

            <label for="computer_serial_number">Computer Serial Number:</label>
            <input type="text" id="computer_serial_number" name="computer_serial_number" required><br>

            <label for="operating_system">Operating System:</label>
            <input type="text" id="operating_system" name="operating_system"><br>

            <label for="software_used">Software Used:</label>
            <input type="text" id="software_used" name="software_used"><br>

            <label for="problem_description">Problem Description:</label>
            <textarea id="problem_description" name="problem_description" required></textarea><br>

            <!-- New Fields -->
            <label for="employee_department">Employee Department:</label>
            <input type="text" id="employee_department" name="employee_department"><br>

            <label for="equipment_type">Equipment Type:</label>
            <input type="text" id="equipment_type" name="equipment_type"><br>
            <!-- New Fields -->

            <hr style="margin-bottom:3%;">
            <h4 style="margin-bottom:3%;">We will contact you within 24 hours.</h4>
            <button type="submit" class="registerbtn" onclick="displayAlert(); pricing();">Submit</button>
        </div>
    </form>

    <script src="script.js"></script>
    <script>
        function displayAlert() {
            alert("Form submitted successfully. We will contact you within 24 hours.");
            return true; // You can return false to prevent the form from actually submitting.
        }
    </script>

    <footer>
        <p style="margin-top:5%;">Copyright &#169; 2023 Group 22. All Rights Reserved.</p>
    </footer>

    <script src="script.js"></script>

</body>
</html>
