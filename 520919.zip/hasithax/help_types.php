<html>

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Help Types</title>
    <link rel="stylesheet" href="home.css" />
    <link rel="stylesheet" href="mediaqueries.css" />
</head>

<body>

    <?php
    require "header.php";
    ?>

    <!--Web help desk-->
    <section id="Web help desk">

        <p class="section__text__p1">More About</p>
        <h1 class="title">Web help desk</h1>

        <div class="section-container">

            <div class="section__pic-container">
                <img src="Customer-Support-1080x675-1.jpg" alt="Profile picture" class="about-pic" />
            </div><span></span><span></span><span></span><span></span>

            <div class="about-details-container">
                <div class="text-container">
                    <p>
                    SaaS help desk software, deployed in the cloud, stores customer service data on the vendor's servers.
                     Businesses subscribe monthly or yearly, inclusive of maintenance, updates, and data storage. 
                     Accessible through an application or vendor's site, this low-maintenance solution is popular among small to medium enterprises. 
                     Large corporations often customize it for scalability.While SaaS offers cost-effective solutions, security and privacy concerns arise as customer data is on the vendor's servers.
                     Businesses must prioritize vendors with high security standards.
                      Recurring pricing may be viewed as a drawback, but it provides flexibility for users to switch without losing investment, motivating vendors to maintain product quality and customer service..<br><br>
                    </p>
                </div>
            </div>

        </div>


    </section>
    <!--Web help desk-->

    <!--On-premise help desk-->
    <section id="On-premise help desk">

        <p class="section__text__p1">More About</p>
        <h1 class="title">On-premise help desk</h1><br>

        <div class="section-container">

            <div class="about-details-container" style="width: 900px;">
                <div class="text-container">
                    <p>
                    This is a help desk that is bought and set up on the customer's servers.
                     After the software is purchased, it is up to the customer to ensure that the system is well maintained, protected and backed up.
                      If the company hosting the help desk has a weak security system, important data and client information could be at risk. However, there are contracts in which the vendor is paid additional charges for maintenance. 
                      Because IT staff have firsthand experience with the company's technical functions, they can ensure that the software transitions smoothly into the business without interrupting existing infrastructure.
                       An on-premise help desk is an expensive and highly customizable investment.
                     For this reason, it may require an on-site technical support team, and is usually aimed at larger corporations.<br><br>
</p>
                </div>
            </div>

            <div class="section__pic-container">
                <img src="images (1).jfif" alt="Profile picture" class="about-pic" />
            </div>

        </div>

    </section>
    <!--On-premise help desk-->

    <!--Enterprise help desk-->
    <section id="Enterprise help desk">

        <p class="section__text__p1">More About</p>
        <h1 class="title">Enterprise help desk</h1>

        <div class="section-container">

            <div class="section__pic-container">
                <img src="images.jfif" alt="Profile picture" class="about-pic" />
            </div><span></span><span></span><span></span><span></span>

            <div class="about-details-container">
                <div class="text-container">
                    <p style="margin-top: 10%;"><br><br>
                    Rather than being aimed at helping customers only, this help desk is also used for in-house assistance. 
                    It is tasked with providing support to both the company's customers and employees so that the former remains satisfied and the latter's productivity is not hindered.
                     The enterprise help desk can include many flexible features such as account management, service request fulfillment, and survey management.
                      It is usually either custom-made to suit an organization's systems or is tailored for a specific business sector.
                       The use of an internal help desk is advantageous to businesses desiring to strengthen ties and communication between departments, while simultaneously helping their customers.<br>
                    </p>
                </div>
            </div>

        </div>


    </section>
    <!--Enterprise help desk-->

    <!--Open-source help desk-->
    <section id="Open-source help desk" style="margin: 5%;">

        <p class="section__text__p1">More About</p>
        <h1 class="title">Open-source help desk</h1><br>

        <div class="section-container">

            <div class="about-details-container" style="width: 900px;">
                <div class="text-container">
                    <p style="margin: 1%;">
                    This help desk is quite common since it is sometimes provided free of charge.
                     Open source software means that anyone has the freedom to access and alter a program's code without needing permission from its producers.
                      A coder can easily improve, strengthen and upgrade any bug fixes in this help desk. One might think that because it is free, small businesses would prefer it over other help desks, but that is not the case.
                       Organizations require highly skilled IT technicians that can successfully manage this fragile and malleable help desk, something that SMEs do not usually have.<br><br>
                    </p>
                </div>
            </div>

            <div class="section__pic-container">
                <img src="download.jfif" alt="Profile picture" class="about-pic" />
            </div>

        </div>

    </section>
    <!--Open-source help desk-->

    <!--Cloud-based help desk-->
    <section id="Cloud-based help desk">

        <p class="section__text__p1">More About</p>
        <h1 class="title">Cloud-based help desk</h1>

        <div class="section-container">

            <div class="section__pic-container">
                <img src="images (2).jfif" alt="Profile picture" class="about-pic" />
            </div><span></span><span></span><span></span><span></span>

            <div class="about-details-container">
                <div class="text-container">
                    <p style="margin-top: 10%;"><br><br>
                    Like all the previously mentioned help desk solutions, cloud-based help desks have the usual features required for ticket management. 
                    However, the main difference lies in their installation and use. 
                    Cloud-based help desks are a combination of web and desktop software applications, meaning that they can be cloud-based, yet locally installed. Moreover, they can be hosted on more than one server and operated by the customer or a third party.
                     The combination of web and desktop based applications of cloud-based help desks means they can function offline and can be accessed anytime, anywhere. Additionally, the fact that they are web-based means that they are scalable and can withstand large amounts of data.
 </p>
                </div>
            </div>

        </div>


    </section>
    <!--Cloud-based help desk--->

    <footer>
        <p>Copyright &#169; 2023 . All Rights Reserved.</p>
    </footer>

    <script src="script.js"></script>

</body>

</html>