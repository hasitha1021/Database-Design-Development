<!DOCTYPE html>
<html>
<head>
    <style>
        .admin-panel {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* Three columns */
            gap: 20px;
            max-width: 1000px;
            height: 200px;
            margin: 0 auto;
        }

        .admin-button {
            background-color: #3498db;
            color: #fff;
            padding: 15px;
            text-align: center;
            font-size: 1.5rem;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
            border-radius: 1.5rem;
        }

        .admin-button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <p style="margin-left: 10%; font-size: 80px; "><b>Admin Panel</b></p>
    <div class="admin-panel" style="margin-top: 5%;">
        <button class="admin-button" onclick="location.href='manageUsers.php'">Manage Users</button>
        <button class="admin-button" onclick="location.href='newAdmin.php'">Add New Admin</button>
        <button class="admin-button" onclick="location.href='manageAdmins.php'">Manage Admin</button>
    </div>
</body>
</html>
