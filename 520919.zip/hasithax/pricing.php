<?php
// Define your dynamic content here
$companyLogoPath = "./images/logo.png";
$pricingPlans = [
    [
        'title' => 'Weddings',
        'description' => 'Make your special day unforgettable with our wedding planning services.',
        'price' => '$10,000 - $15,000',
        'link' => 'wedding.html'
    ],
    // Add other pricing plans here
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing</title>
    <link rel="stylesheet" type="text/css" href="1.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .banner {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        .logo {
            width: 150px;
        }

        .navbar {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }

        .pricing-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            padding: 20px;
        }

        .pricing-plan {
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            padding: 20px;
            margin: 10px;
            text-align: center;
            width: 30%;
        }

        .pricing-plan h2 {
            color: #333;
        }

        .price {
            font-size: 24px;
            color: #007BFF;
        }

        .btn {
            display: inline-block;
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .footer-content {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        .footer-logo img {
            width: 100px;
        }

        .footer-social li {
            display: inline;
            margin: 0 10px;
        }

        .footer-bottom {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <section>
        <header class="banner">
            <img src="<?php echo $companyLogoPath; ?>" alt="Company Logo" class="logo">
        </header>
    </section>
    <section>
        <h1>Pricing</h1>
        <div class="pricing-container">
            <?php foreach ($pricingPlans as $plan): ?>
                <div class="pricing-plan">
                    <h2><?php echo $plan['title']; ?></h2>
                    <p><?php echo $plan['description']; ?></p>
                    <p class="price"><?php echo $plan['price']; ?></p>
                    <a href="<?php echo $plan['link']; ?>" class="btn">Get Started</a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="<?php echo $companyLogoPath; ?>" alt="Your Company Logo">
            </div>
            <div class="footer-social">
                <ul>
                    <li><a href="#">facebook</i></a></li>
                    <li><a href="#">twitter</i></a></li>
                    <li><a href="#">linkedin</i></a></li>
                    <li><a href="#">instagram</i></a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Your Company. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
