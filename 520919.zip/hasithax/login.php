<?php
session_start();
require "connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if (empty($username) || empty($password)) {
        echo "Please enter both username and password";
    } else {
        // Use prepared statements to prevent SQL injection
        $stmt = $connection->prepare("SELECT * FROM `user` WHERE `username` = ? AND `password` = ?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            // Password is correct, log in the user
            $user = $result->fetch_assoc();
            $_SESSION["user_id"] = $user["id"];

            // Redirect to a welcome page or any other page after successful login
            header("Location: afterlogin.php");
            exit();
        } else {
            echo "Invalid username or password";
        }

        $stmt->close();
    }
}
?>


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>

<body>

    <div class="center">
        <h1>LOGIN</h1>
        <div class="panel">
            <form id="loginForm" method="post" action="login.php">
                <div class="txt_field">
                    <input type="text" name="username" id="username" required>
                    <span></span>
                    <label>Username</label>
                </div>

                <div class="txt_field">
                    <input type="password" name="password" id="password" required>
                    <span></span>
                    <label>Password</label>
                </div>

                <input type="submit" value="Login">
            </form>

            <div class="signup_link">
                Not a member? <a href="signup.php">Signup</a>
            </div>
        </div>
    </div>

    <script src="script.js"></script>

</body>

</html>
