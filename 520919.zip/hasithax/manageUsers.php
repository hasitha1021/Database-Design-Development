<?php
require "connection.php";
?>

<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      width: 200px;
    }

    .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
    }

    .container {
      padding: 2px 16px;
    }

    .admin-panel {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      /* Three columns */
      gap: 20px;
      max-width: 1000px;
      margin: 0 auto;
    }
  </style>
  <link rel="stylesheet" href="s.css">
</head>

<body id="b">

  <h2>Manage Users</h2>

  <div class="admin-panel" style="margin-top: 5%;">
    <?php

    $user_rs = Database::search("SELECT * FROM `user`");

    $u = $user_rs->num_rows;
    $cards_per_row = 3; // Changed to 3 for better grid layout
    $total_cards = $user_rs->num_rows;
    $card_count = 0; // Counter for tracking the number of cards in the current row

    while ($ud = $user_rs->fetch_assoc()) {
      // Start a new row if needed
      if ($card_count % $cards_per_row === 0) {
        echo '<div class="row">';
      }

      // Display the user card
      ?>
      <div class="card">
        <img src="newuser.svg" alt="Avatar" style="width:100%">
        <div class="container">
          <h4><b><?php echo $ud["name"]; ?></b></h4>
          <p><?php echo $ud["email"]; ?></p>
          <div>
            <button type="button" class="registerbtn"><a href="updateUser.php?id=<?php echo $ud['id'] ?>">Update</a></button>
            <button type="button" class="registerbtn" onclick="deleteUser(<?php echo $ud['id'] ?>);">Delete</button>
          </div>
        </div>
      </div>
    <?php

      // Increment the card count
      $card_count++;

      // Close the row if needed
      if ($card_count % $cards_per_row === 0 || $card_count == $total_cards) {
        echo '</div>';
      }
    }

    ?>
  </div>

  <script src="script.js"></script>

</body>

</html>
