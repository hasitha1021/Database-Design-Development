<?php
session_start();
?>

<nav id="desktop-nav">
    <div class="logo">Help me</div>
    <div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li><a href="help_types.php">Help Type</a></li>
            <li><a href="service.php">Services</a></li>
            <li>
                

                    <a href="login.php"> Help me<br>(are you login?)</a>

                
            </li>
            <li><a href="contact.php">contact</a></li>
            <li>
                <?php
                if (isset($_SESSION["u"])) {
                ?>

                    <span onclick="sign_Out();">Sign Out</span>

                <?php
                } else {
                ?>

                    <a href="login.php">Login</a>

                <?php
                }
                ?>
            </li>
        </ul>
    </div>
</nav>

<nav id="hamburger-nav">
    <div class="logo">Help me</div>
    <div class="hamburger-menu">
        <div class="hamburger-icon" onclick="toggleMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div class="menu-links">
            <li><a href="home.php">Home</a></li>
            <li><a href="event.php">Help Type</a></li>
            <li><a href="service.php">Services</a></li>
            <li>
                <?php
                if (isset($_SESSION["u"])) {
                ?>

                    <a href="help_me.php">Help me</a>

                <?php
                } else {
                ?>

                    <a href="login.php">Help me</a>

                <?php
                }
                ?>
            </li>
            <li><a href="contact.php">contact</a></li>
            <li>
                <?php
                if (isset($_SESSION["u"])) {
                ?>

                    <span onclick="sign_Out();">Sign Out</span>

                <?php
                } else {
                ?>

                    <a href="login.php">Login</a>

                <?php
                }
                ?>
            </li>
        </div>
    </div>
</nav>
