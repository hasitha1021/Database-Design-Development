<?php
require "connection.php";
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="s.css">
</head>

<body style="margin-left: 30%; margin-right: 30%; margin-top: 5%;">


    <div class="container">
        <h1>Add Update Admin</h1>
        <p>Please fill in this form to update admin.</p>
        <hr>

        <?php

        $id = $_GET["id"];

        $admin_rs = Database::search("SELECT * FROM `new admin` WHERE `id`='" . $id . "' ");
        $admin_num = $admin_rs->num_rows;
        $admin_data = $admin_rs->fetch_assoc();


        ?>

        <label for="name"><b>Name</b></label>
        <input type="text" placeholder="Enter Name" name="name" id="name" value="<?php echo $admin_data["name"] ?>" required>

        <label for="username"><b>Username</b></label>
        <input type="text" placeholder="Enter Userame" name="username" id="username" value="<?php echo $admin_data["username"] ?>" required>

        <label for="email"><b>Email</b></label>
        <input type="text" placeholder="Enter Email" name="email" id="email" value="<?php echo $admin_data["email"] ?>" required>

        <label for="mobile"><b>Mobile</b></label>
        <input type="text" placeholder="Enter Mobile" name="mobile" id="mobile" value="<?php echo $admin_data["mobile"] ?>" required>

        <label for="psw"><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="psw" id="password" value="<?php echo $admin_data["password"] ?>" required>

        <hr>
        <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>

        <button type="submit" class="registerbtn" onclick="updateAdmin($id);">Update Admin</button>
    </div>


    <script src="script.js"></script>

</body>

</html>