<?php

class Database
{
    private static $connection;

    public static function connect()
    {
        $host = "localhost";
        $username = "root";
        $password = "1234";
        $database = "helpdesk";

        self::$connection = new mysqli($host, $username, $password, $database);

        if (self::$connection->connect_error) {
            die("Connection failed: " . self::$connection->connect_error);
        }
    }

    public static function search($query)
    {
        if (!isset(self::$connection)) {
            self::connect();
        }

        $result = self::$connection->query($query);

        if (!$result) {
            die("Query failed: " . self::$connection->error);
        }

        return $result;
    }
}

?>

