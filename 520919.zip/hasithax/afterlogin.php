<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        nav {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-around;
        }

        nav a {
            text-decoration: none;
            color: white;
        }

        img {
            width: 100%;
            max-width: 800px;
            height: auto;
            margin: 20px 0;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        iframe {
            width: 100%;
            max-width: 800px;
            height: 400px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>

<body>

    <nav>
        <div class="logo">Help me</div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li><a href="help_types.php">Help Types</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="help_me.php">Help me</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="logout.php">Logout</a></li>
             <!-- Add Update User button -->
        <a href="updateuser.php" class="update-btn">Update User Information</a>

<!-- Add other content of your afterlogin.php page here -->

        </ul>
    </nav>

    <div>
    <img src="download.png" alt="Download Image" style="width: 10%; max-width: 800px; height: auto; margin: 20px 0; display: block; margin-left: auto; margin-right: auto;">
</div>


    <div>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/m_kD9-JVWm4?si=Ojw_il0TXnz0mqF_&autoplay=1" frameborder="0" allowfullscreen allow="autoplay"></iframe>
    </div>

</body>

</html>
