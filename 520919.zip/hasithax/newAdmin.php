<?php
require "connection.php";
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="s.css">
</head>

<body style="margin-left: 30%; margin-right: 30%; margin-top: 5%;">

<form id="adminForm" method="post" action="process_admin.php">
    <div class="container">
        <h1>Add New Admin</h1>
        <p>Please fill in this form to create new admin.</p>
        <hr>

        <label for="name"><b>Name</b></label>
        <input type="text" placeholder="Enter Name" name="name" id="name" required>

        <label for="username"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="username" id="username" required>

        <label for="email"><b>Email</b></label>
        <input type="text" placeholder="Enter Email" name="email" id="email" required>

        <label for="mobile"><b>Mobile</b></label>
        <input type="text" placeholder="Enter Mobile" name="mobile" id="mobile" required>

        <label for="psw"><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="psw" id="password" required>

        <hr>
        <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>

        <button type="submit" class="registerbtn" onclick="signUp();">Create New admin</button>
    </div>

    <div class="container signin">
        <p>Already have an account? <a href="login.php">Sign in</a>.</p>
    </div>
    
</form>

    <script src="script.js"></script>
  
</body>

</html>