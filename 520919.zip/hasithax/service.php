<?php
// Define your dynamic content for services here
$companyLogoPath = "download.png";
$services = [
    [
        'title' => 'Incident management',
        'description' => 'Reduce service disruptions, meet your SLAs, improve technicians productivity, and manage the entire life cycle of a ticket.',
        'link' => 'process_form.php'
    ],
    [
        'title' => 'Problem management',
        'description' => 'Analyze the root cause of problems and reduce recurring incidents.',
        'link' => 'process_form.php'
    ],
    [
        'title' => 'Change management',
        'description' => 'Plan, analyze, and implement IT changes with visual workflows.',
        'link' => 'process_form.php'
    ],
    [
        'title' => 'Asset management',
        'description' => 'Gain complete visibility into your assets, improve asset utilization, and manage software licenses with expiration notifications.',
        'link' => 'process_form.php'
    ],
    [
        'title' => 'Service Catalog',
        'description' => 'Showcase all the business and technology-related services offered by your organization.',
        'link' => 'process_form.php'
    ],
    [
        'title' => 'IT Project management',
        'description' => 'Plan, organize, and assign tasks effectively for all projects, and associate projects with changes and problems to enhance your IT service delivery.',
        'link' => 'process_form.php'
    ],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="stylesheet" type="text/css" href="1.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .banner {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        .logo {
            width: 150px;
        }

        .navbar {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }

        .pricing-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            padding: 20px;
        }

        .pricing-plan {
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            padding: 20px;
            margin: 10px;
            text-align: center;
            width: 30%;
        }

        .pricing-plan h2 {
            color: #333;
        }

        .price {
            font-size: 24px;
            color: #007BFF;
        }

        .btn {
            display: inline-block;
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .footer-content {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        .footer-logo img {
            width: 100px;
        }

        .footer-social li {
            display: inline;
            margin: 0 10px;
        }

        .footer-bottom {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <section>
        <header class="banner">
            <img src="<?php echo $companyLogoPath; ?>" alt="Company Logo" class="logo">
        </header>
    </section>
    <section>
        <nav class="navbar">
            <!-- Your existing navigation code -->
        </nav>
    </section>
    <section>
        <h1>Services</h1>
        <div class="pricing-container">
            <?php foreach ($services as $service): ?>
                <div class="pricing-plan">
                    <h2><?php echo $service['title']; ?></h2>
                    <p><?php echo $service['description']; ?></p>
                    <a href="<?php echo $service['link']; ?>" class="btn">Learn More</a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="<?php echo $companyLogoPath; ?>" alt="Your Company Logo">
            </div>
            <div class="footer-social">
                <!-- Your social media links -->
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Your Company. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
