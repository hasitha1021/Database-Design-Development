<?php
require "connection.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = $_POST['psw'];

    // Perform database insert
    $query = "INSERT INTO `new admin` (name, username, email, mobile, psw) 
              VALUES ('$name', '$username', '$email', '$mobile', '$password')";

    if ($connection) {
        $result = mysqli_query($connection, $query);

        if ($result) {
            echo "Admin added successfully!";
        } else {
            echo "Error: " . mysqli_error($connection);
        }

        // Close database connection
        mysqli_close($connection);
    } else {
        echo "Error: Unable to establish a database connection.";
    }
}
?>
