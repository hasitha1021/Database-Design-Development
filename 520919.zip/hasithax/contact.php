<html>

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact</title>
    <link rel="stylesheet" href="home.css" />
    <link rel="stylesheet" href="mediaqueries.css" />
</head>

<body>

    <?php
    require "header.php";
    ?>

    <section id="contact">
        <h2>Contact Us</h2>
        <p>If you couldn't find the answer to your question in our FAQs or need further assistance, please don't hesitate to contact us:</p>
        <ul>
            <li>Email: <a href="mailto:contact@eventbreeze.com">contact@eventbreeze.com</a></li>
            <li>Phone: <a href="tel:+0711275269">0711275269</a></li>
            <li>Visit our office: 123 Main Street, Nugegoda, Colombo</li>
        </ul>
    </section>

    <section id="ask-question">
        <h2>Ask a Question</h2>
        <form action="submit_question.php" method="post">
            <label for="question">Your Question:</label><br>
            <textarea id="question" name="question" rows="4" cols="50" required></textarea><br>
            <input type="submit" value="Submit">
        </form>
    </section>

    <section id="request-call">
        <h2>Request a Call</h2>
        <p>Would you like us to call you back? Please provide your contact information, and we'll get in touch with you.</p>
        <form action="request_call.php" method="post">
            <label for="name">Your Name:</label><br>
            <input type="text" id="name" name="name" required><br>
            <label for="phone">Phone Number:</label><br>
            <input type="tel" id="phone" name="phone" required><br>
            <input type="submit" value="Request Call">
        </form>
    </section>

    <footer>
        <p>Copyright &#169; 2023. All Rights Reserved.</p>
    </footer>

    <script src="script.js"></script>

</body>

</html>
