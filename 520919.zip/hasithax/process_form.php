<?php
// db_connection.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "helpdesk";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php
// process_form.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];

    // Save the uploaded PDF file
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["pdf"]["name"]);
    move_uploaded_file($_FILES["pdf"]["tmp_name"], $target_file);

    // Insert data into the 'project_submissions' table
    $sql = "INSERT INTO project_submissions ('name', 'email') VALUES ($name,$email)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $email, $target_file);
    $stmt->execute();

    // Send email notification
    $to = "your_email@example.com";
    $subject = "New Project Submission";
    $message = "Name: $name\nEmail: $email\nPDF File: $target_file\n";
    $headers = "From: webmaster@example.com";

    mail($to, $subject, $message, $headers);

    $stmt->close();
    $conn->close();

    echo "Form submitted successfully. We will contact you soon.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Submission Form</title>
</head>

<body>

    <form action="process_form.php" method="post" enctype="multipart/form-data">
        <label for="name">Your Name:</label>
        <input type="text" name="name" required><br>

        <label for="email">Your Email:</label>
        <input type="email" name="email" required><br>

        <label for="pdf">Upload PDF:</label>
        <input type="file" name="pdf" accept=".pdf" required><br>

        <button type="submit">Submit</button>
    </form>

</body>

</html>
