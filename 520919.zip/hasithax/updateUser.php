<?php
// updateuser.php

require "connection.php";

// Check if the user is logged in (you may need to implement a login system)
// For demonstration purposes, let's assume you have a session variable 'user_id'
session_start();
if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: updareuser.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $mobile = $_POST["mobile"];
    $password = $_POST["psw"];

    // Update user in the database (assuming you have a table named 'users')
    $sql = "UPDATE users SET 
            name = ?, 
            email = ?, 
            mobile = ?, 
            password = ? 
            WHERE id = ?";

    // Use prepared statement to prevent SQL injection
    $stmt = mysqli_prepare($conn, $sql);
    
    // Bind parameters
    mysqli_stmt_bind_param($stmt, "ssssi", $name, $email, $mobile, $password, $user_id);

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        echo "User updated successfully";
    } else {
        echo "Error updating user: " . mysqli_error($conn);
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}

// Fetch the user's current information for pre-filling the form
$result = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$row = mysqli_fetch_assoc($result);

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="s.css">
</head>

<body style="margin-left: 30%; margin-right: 30%; margin-top: 5%;">

    <form id="userForm" method="post" action="updateuser.php">

        <div class="container">
            <h1>Update User Information</h1>
            <p>Please update your information below.</p>
            <hr>

            <label for="name"><b>Name</b></label>
            <input type="text" placeholder="Enter Name" name="name" id="name" value="<?php echo $row['name']; ?>" required>

            <label for="email"><b>Email</b></label>
            <input type="text" placeholder="Enter Email" name="email" id="email" value="<?php echo $row['email']; ?>" required>

            <label for="mobile"><b>Mobile</b></label>
            <input type="text" placeholder="Enter Mobile" name="mobile" id="mobile" value="<?php echo $row['mobile']; ?>" required>

            <label for="psw"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="psw" id="password" required>

            <hr>

            <button type="submit" class="registerbtn">Update Information</button>
        </div>
    </form>

    <script src="script.js"></script>
</body>

</html>
