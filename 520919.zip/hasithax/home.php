<html>

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Help Desk</title>
    <link rel="stylesheet" href="home.css" />
    <link rel="stylesheet" href="mediaqueries.css" />
</head>

<body>

    <?php
    require "header.php";
    ?>

    <!--banner-->
    <section id="banner">

            <div id="socials-container">
                <img src="help-desk-banner-image.png" style="width:130%;"/>

    </section>
    <!--banner-->

    <!--help types-->
    <section id="events"style="margin-top: 10%;">

        <p class="section__text__p1">explore more about</p>
        <h1 class="title">Help Types</h1>

        <div class="experience-details-container">
            <div class="about-containers">

                <div class="details-container color-container">

                    <div class="article-container">
                        <img src="newuser.svg" alt="Project 1" class="project-img" />
                    </div>

                    <h2 class="experience-sub-title project-title">Web help desk</h2>

                    <div class="btn-container">
                        <button class="btn btn-color-2 project-btn" onclick="location.href='help_types.php#Web help desk'">Browse</button>
                    </div>

                </div>

                <div class="details-container color-container">

                    <div class="article-container">
                        <img src="newuser.svg" alt="Project 2" class="project-img" />
                    </div>

                    <h2 class="experience-sub-title project-title">On-premise help desk</h2>

                    <div class="btn-container">
                        <button class="btn btn-color-2 project-btn" onclick="location.href='help_types.php#On-premise help desk'">Browse</button>
                    </div>

                </div>

                <div class="details-container color-container">

                    <div class="article-container">
                        <img src="newuser.svg" alt="Project 3" class="project-img" />
                    </div>

                    <h2 class="experience-sub-title project-title">Enterprise help desk</h2>

                    <div class="btn-container">
                        <button class="btn btn-color-2 project-btn" onclick="location.href='help_types.php#Enterprise help desk'">Browse</button>
                    </div>

                </div>

                <div class="details-container color-container">

                    <br><br><br><br><br><br>

                    <h2 class="experience-sub-title project-title">More Events</h2>

                    <div class="btn-container">
                        <button class="btn btn-color-2 project-btn" onclick="location.href='help_types.php'">Explore</button>
                    </div>

                </div>



            </div>
        </div>

    </section>
    <!--help types-->

    <!--service-->
    <section id="experience">

        <p class="section__text__p1">Introduce our</p>
        <h1 class="title">Services</h1>


        <div class="experience-details-container">
            <div class="about-containers">

                <div class="details-container color-container">

                    <div class="article-container">
                        <img src="newuser.svg" alt="Project 1" class="project-img" />
                    </div>

                    <h2 class="experience-sub-title project-title">Incident management</h2>

                    <div class="btn-container">
                        <button class="btn btn-color-2 project-btn" onclick="location.href='service.php#Incident management'">Browse</button>
                    </div>

                </div>

                <div class="details-container color-container">

                    <div class="article-container">
                        <img src="newuser.svg" alt="Project 2" class="project-img" />
                    </div>

                    <h2 class="experience-sub-title project-title">Problem management</h2>

                    <div class="btn-container">
                        <button class="btn btn-color-2 project-btn" onclick="location.href='service.php#Problem management'">Browse</button>
                    </div>

                </div>

                <div class="details-container color-container">

                    <div class="article-container">
                        <img src="newuser.svg" alt="Project 3" class="project-img" />
                    </div>

                    <h2 class="experience-sub-title project-title">Change management</h2>

                    <div class="btn-container">
                        <button class="btn btn-color-2 project-btn" onclick="location.href='service.php#Change management'">Browse</button>
                    </div>

                </div>

                <div class="details-container color-container">

                    <br><br><br><br><br><br>

                    <h2 class="experience-sub-title project-title">More Services</h2>

                    <div class="btn-container">
                        <button class="btn btn-color-2 project-btn" onclick="location.href='service.php'">Explore</button>
                    </div>

                </div>



            </div>
        </div>

    </section>
    <!--service-->

   
    <footer>
        <p>Copyright &#169; 2023 . All Rights Reserved.</p>
    </footer>

    <script src="script.js"></script>

</body>

</html>